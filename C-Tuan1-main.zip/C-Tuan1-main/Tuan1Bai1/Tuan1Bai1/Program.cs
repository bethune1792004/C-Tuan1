﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap so nguyen a: ");
        int a = int.Parse(Console.ReadLine());
        Console.Write("Nhap so nguyen b: ");
        int b = int.Parse(Console.ReadLine());
        double result;
        result = a + b;
        Console.WriteLine($"Ket qua: {a} + {b} = {result}");
        result = a - b;
        Console.WriteLine($"Ket qua: {a} - {b} = {result}");
        result = a * b;
        Console.WriteLine($"Ket qua: {a} * {b} = {result}");
        if (b != 0)
        {
            result = (double)a / b;
            Console.WriteLine($"Ket qua: {a} / {b} = {result}");
        }
        else
        {
            Console.WriteLine("Không the chia cho 0.");
        }
    }
}
