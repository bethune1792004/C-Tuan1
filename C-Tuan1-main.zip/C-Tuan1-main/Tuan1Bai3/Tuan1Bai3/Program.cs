﻿using System;

class Program
{
    static void Main()
    {
        int n;

        do
        {
            Console.Write("Nhap mot so nguyen n (n >= 2): ");
            n = int.Parse(Console.ReadLine());
        } while (n < 2);

        if (IsPrime(n))
        {
            Console.WriteLine($"{n} la so nguyen to.");
        }
        else
        {
            Console.WriteLine($"{n} không phai la so nguyen to.");
        }
    }

    static bool IsPrime(int number)
    {
        if (number < 2) return false;

        for (int i = 2; i <= Math.Sqrt(number); i++)
        {
            if (number % i == 0) return false;
        }

        return true;
    }
}